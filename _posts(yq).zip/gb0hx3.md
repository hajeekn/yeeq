---

title: 博客效果展示
sticky: 1

abbrlink: e8563c5f
date: 2020-05-27 20:39:32
tags:
description:
cover: "[https://cdn.jsdelivr.net/gh/slblog-github/BlogFlies/Blog/Pic/2527Cover.png](https://cdn.jsdelivr.net/gh/slblog-github/BlogFlies/Blog/Pic/2527Cover.png)"

---

下面上效果展示

错误标签

警告标签

成功标签

默认标签

测

a

Hexo

{% hideInline 海内存知己‚天涯若比邻,开始背书,bg,color %}

{% note primary %}

初级标签

{% endnote %}

{% note success %}

Codeblock in note

成功标签

{% endnote %}

{% note info %}

Info Header

信息标签

{% endnote %}

{% note warning %}

Warning Header

警告标签

{% endnote %}

{% note danger %}

Danger Header

危险标签

{% endnote %}

{% note info no-icon %}

No icon note

`note info no-icon`

无图标标签

{% endnote %}

{% code %}

代码框标签，效果和``一样

{% endcode %}

黄色色块

左边框红色块级

{% checkbox 纯文本测试 %}

{% checkbox checked, 支持简单的 markdown 语法 %}

{% checkbox red, 支持自定义颜色 %}

{% checkbox green checked, 绿色 + 默认选中 %}

{% checkbox yellow checked, 黄色 + 默认选中 %}

{% checkbox cyan checked, 青色 + 默认选中 %}

{% checkbox blue checked, 蓝色 + 默认选中 %}

{% checkbox plus green checked, 增加 %}

{% checkbox minus yellow checked, 减少 %}

{% checkbox times red checked, 叉 %}

{% hideToggle 测试 %}

测试一下

{% endhideToggle %}

{% hideInline 我是答案,看看答案,bg,color %}

这是黑体字

这是微软雅黑

这是华文彩云

三号蓝色黑体

四号青色字

五号灰色字

[点击下载](https://pan.baidu.com/)

[点击下载](https://pan.baidu.com/)

[点击下载](https://pan.baidu.com/)

[点击下载](https://pan.baidu.com/)

[点击下载](https://pan.baidu.com/)

[点击下载](https://pan.baidu.com/)

[点击下载](https://pan.baidu.com/)

[点击下载](https://pan.baidu.com/)

{% btns %}

{% cell 看看更新吧, /update, far fa-hand-point-right %}

{% endbtns %}

{% link 如何参与项目, [http://localhost:4000/contributors/](http://localhost:4000/contributors/), [https://cdn.jsdelivr.net/gh/volantis-x/cdn-org/blog/Logo-NavBar@3x.png](https://cdn.jsdelivr.net/gh/volantis-x/cdn-org/blog/Logo-NavBar@3x.png) %}

{% timeline 碎碎念 %}

{% timenode 2020-08-06 [连接测试](https://xiaokang.me) %}

今天是 2020-08-06

{% endtimenode %}

{% timenode 2020-08-05 [连接测试](https://xiaokang.me) %}

今天是 2020-08-05

{% endtimenode %}

{% endtimeline %}

{% folding 查看图片测试 %}

![](https://cdn.jsdelivr.net/gh/volantis-x/cdn-wallpaper/abstract/41F215B9-261F-48B4-80B5-4E86E165259E.jpeg#alt=)

{% endfolding %}

{% folding cyan open, 查看默认打开的折叠框 %}

这是一个默认打开的折叠框。

{% endfolding %}

{% folding green, 查看代码测试 %}

{% endfolding %}

{% folding yellow, 查看列表测试 %}

- haha
- hehe

{% endfolding %}

{% folding red, 查看嵌套测试 %}

{% folding blue, 查看嵌套测试2 %}

{% folding 查看嵌套测试3 %}

hahaha ![](https://cdn.jsdelivr.net/gh/volantis-x/cdn-emoji/tieba/%E6%BB%91%E7%A8%BD.png#)

{% endfolding %}

{% endfolding %}

{% endfolding %}
