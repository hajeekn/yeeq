---


title: 如何白嫖免费域名

sticky: 1

abbrlink: dcfdf76e

date: 2020-05-01 09:28:38

tags: 白嫖党福利

description:

- 白嫖
- 域名

cover: "[https://cdn.jsdelivr.net/gh/slblog-github/BlogFlies/Blog/Pic/2725Cover.png](https://cdn.jsdelivr.net/gh/slblog-github/BlogFlies/Blog/Pic/2725Cover.png)"

---

今天小编(划掉)教大家如何白嫖免费域名啦~

第一步:下载本站提供的集装箱插件，拖动到 Chrome 里。

低速下载(走服务器流量)：https://www.slblog.ga/集装箱.crx

觉得这个下载慢可以试试高速下载哦

高速下载(走 CF 高级版 CDN)：https://cdn.slblog.ga/集装箱.crx

如果无法安装请打开开发者模式并将 crx 解压后选择加载一解压的扩展程序

然后点击集装箱插件-谷歌助手-开启代理

第二步：打开www.freenom.com

![](https://cdn.slblog.ga/pic/post/qwq.png#)

在方框里输入你想要的域名(带后缀哦)

后缀类型：.tk，.ml，.ga，.gq，.cf

这边用 dodola.ml 举例子

点击完成，稍等一会儿他就会跳转至下一步

网站加载可能稍慢

接着点击

![](https://cdn.slblog.ga/pic/post/sss.png#)

将 3 Months @ FREE 改为 12 Months @ FREE

PS:Use Dns 代表自定义 DNS

Forward this domain 代表将域名跳转至某域名

当这一步做好后点击 Continue

接下来会跳转至

![](https://cdn.slblog.ga/pic/post/rrrr.png#)

在 Enter Your Email Address 填写你的域名

然后点击 Verify My Email Address

这时候 Freenom 将会给你发一封邮件

在邮件内部找到 Verify My Email Address

点击一下，就会跳转至一个页面，下面让你填写真实信息，推荐和自己 IP 一样，否则可能结算报错。

填写好后将下面的小方块打上勾，点击下一步(应该是的)

然后跳转至一个页面，看看上面有没有 Error 之类的报错，如果没有，恭喜你，注册成功!

下面是修改 DNS 教程

打开https://my.freenom.com/clientarea.php?action=domains

找到你刚才嫖的域名点击后面的 Manage Domain

然后找到 Management Tools-Nameserver

选择 Use custom nameservers(enter below)

将下面的 Nameserver 改成你想用的 DNS

这时候一年的域名就白嫖完成啦~

续费也是免费的哦！

PS:白嫖的域名现在无法使用 CF 啦(无法解析！)
