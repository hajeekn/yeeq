---

title: More-Beautiful-Div-Framework
sticky: 1

tags: Hexo
abbrlink: 7d8b55fe
date: 2020-06-14 12:32:18
description: 都 2020 年了，还在用老土的 CSS 框架?
cover: "[https://cdn.jsdelivr.net/gh/slblog-github/BlogFlies/Blog/Pic/2614Cover.png](https://cdn.jsdelivr.net/gh/slblog-github/BlogFlies/Blog/Pic/2614Cover.png)"

---

```
      - <link rel="stylesheet" href="https://unpkg.com/more-beautiful-div-framework/more-beautiful-div-framework.min.css">
      - <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free/css/all.min.css">
      - <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/More-Beautiful-Div-Framework/More-Beautiful-Div-Framework-CDN/yl-if.css">
```

网页引用方法:

网页 head 处添加

```
<link rel="stylesheet" href="https://unpkg.com/more-beautiful-div-framework/more-beautiful-div-framework.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free/css/all.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/More-Beautiful-Div-Framework/More-Beautiful-Div-Framework-CDN/yl-if.css">
```

文章内引用方法:

```
<div class="tip lite"><p>文字</p><p></p></div>
<div class="tip ban"><p>文字</p><p></p></div>
<div class="tip home"><p>文字</p><p></p></div>
<div class="tip impo"><p>魔改标签4</p><p></p></div>
<div class="tip ref"><p>魔改标签5</p><p></p></div>
<div class="tip set"><p>魔改标签6</p><p></p></div>
<div class="tip key"><p>魔改标签7</p><p></p></div>
<div class="tip bell"><p>魔改标签8</p><p></p></div>
<div class="tip qq"><p>魔改标签9</p><p></p></div>
```

例子:

魔改标签 1

魔改标签 2

魔改标签 3

魔改标签 4

魔改标签 5

魔改标签 6

魔改标签 7

魔改标签 8

魔改标签 9

目前此拓展会持续更新

# 依赖

依赖如下:

FontAwesome 5 / 4(除 QQ 样式以外的其他样式依赖项)

iconfont(QQ 样式的依赖项)

# 更新日志:

2020/8/36

18:30 版本号 V1.9

更换部分标签引用名称

2020/6/22

14:05 版本号 V1.8

将 QQ 样式的图标替换为 iconfont 图标

2020/6/17

20:29 版本号 V1.7(跳过 1.6)

添加压缩过的 css(more-beautiful-div-framework.min.css)

提供 jsdelivr 的 CSS 地址

兼容 V5

添加 QQ 样式

17:52 版本号 V1.5

取消 pool.css 依赖

将 jsdelivr 地址换为 unpkg 地址

2020/6/15

14:55 版本号 V1.4

添加 socd 样式

2020/6/14

18:20 版本号 V1.3

添加 ref、ffa、key 样式

14:45 版本号 V1.2

添加 important 样式

12:30 版本号 V1.1

添加 Home 样式

12:00 版本号 V1.0

添加 Wtgo、ban2 种样式

10:00

开启此项目
