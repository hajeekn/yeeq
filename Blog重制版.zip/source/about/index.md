---
title: about
sticky: 1
comments: false
aside: false
---
{% raw %}
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/dreamy-tzk/Static_butterfly/dist/css/051eaa7d.min.css">
<center><img src="https://rmt.dogedoge.com/fetch/hajeekn/storage/Logo@B_3508X4961.png?w=141" data-fancybox="group" data-caption="My Avatar" class="fancybox"></center>
<style>@font-face{font-family:myfont;font-weight:700;src:url(https://cdn.jsdelivr.net/gh/sviptzk/xiaokang.me/www/myfont.ttf)}</style>
<center style="font-size:1.7rem;background-image:linear-gradient(92deg,#f35626 0,#feab3a 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;font-family:myfont">Hajeekn</center>
{% endraw %}
🍀 个人简介
{% checkbox green checked, 初中 现居住:🌏 保持一颗充满童趣的心♥ %}
🌌 博客简介
{% checkbox plus green checked, 全站HTTPS %}
{% checkbox plus green checked, 静态博客(Hexo) + 近完美主题(Butterfly) %}
{% checkbox plus red checked, 博客中少部分图片收集于Network 侵删 %}
☁ 个人基本信息
各账户主要情况:
![](https://github-stats.hclonely.com/api/top-langs/?username=glahajeekn)
![](https://github-stats.hclonely.com/api/top-langs/?username=slblog-github)
![](https://github-stats.hclonely.com/api/top-langs/?username=Open-super)
各账户GitHub状态:
![](https://github-stats.hclonely.com/api?username=glahajeekn&show_icons=true&count_private=true&layout=compact&theme=vue)
![](https://github-stats.hclonely.com/api?username=slblog-github&show_icons=true&count_private=true&layout=compact&theme=vue)
![](https://github-stats.hclonely.com/api?username=Open-super&show_icons=true&count_private=true&layout=compact&theme=vue)
