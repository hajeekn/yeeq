---
title: Speak
date: 2020-08-09 22:38:04
top_img: https://tva1.sinaimg.cn/large/005B3XPgly1ghkxqgvmy0j30zk0irn2q.jpg
aside: false
comments: false
description: 欢迎来到SL的Speak页面，快来看看小康都说了什么吧！
---
<script>$(document).ready(function () {
    if(location.href.indexOf("#reloaded")==-1){
        location.href=location.href+"#reloaded";
        location.reload();
    }
})</script>
<script async src="https://busuanzi.ibruce.info/busuanzi/2.3/busuanzi.pure.mini.js"></script>
<style>*{box-sizing:border-box;outline:0;margin:0;padding:0}#loading-bar-wrapper{position:fixed;width:100px;top:8px;left:50%;transform:translateX(-50%);height:8px;border-radius:8px;z-index:99999;background:0 0}#loading-bar-wrapper.nprogress-custom-parent{background:var(--color-card);box-shadow:0 1px 2px 0 rgba(0,0,0,.1)}.loading-circle{display:none;height:100%;width:100%;position:fixed;top:0;left:0;z-index:999999;background-color:rgba(250,250,250,.9)}.loading-circle img{width:280px;height:210px;position:relative;top:45%;left:50%;margin-left:-140px;margin-top:-105px}#loader-circle{display:block;position:relative;left:50%;top:50%;width:150px;height:150px;margin:-75px 0 0 -75px;border-radius:50%;border:3px solid transparent;border-top-color:#ff5a5a;animation:spin 1s linear infinite}#loader-circle:before{content:"";position:absolute;top:5px;left:5px;right:5px;bottom:5px;border-radius:50%;border:3px solid transparent;border-top-color:#5af33f;animation:spin 3s linear infinite}#loader-circle:after{content:"";position:absolute;top:15px;left:15px;right:15px;bottom:15px;border-radius:50%;border:3px solid transparent;border-top-color:#6dc9ff;animation:spin 2s linear infinite}.fa-cog:before{content:"\f013";color:#0ee4e4}.fuck{color:#0ee4e4}</style>
<script src="https://cdn.jsdelivr.net/npm/jquery@latest/dist/jquery.min.js"></script>

<style>.hljs{display:block;overflow-x:auto;padding:.5em;background:#23241f}.hljs,.hljs-subst,.hljs-tag{color:#f8f8f2}.hljs-emphasis,.hljs-strong{color:#a8a8a2}.hljs-bullet,.hljs-link,.hljs-literal,.hljs-number,.hljs-quote,.hljs-regexp{color:#ae81ff}.hljs-code,.hljs-section,.hljs-selector-class,.hljs-title{color:#a6e22e}.hljs-strong{font-weight:700}.hljs-emphasis{font-style:italic}.hljs-attr,.hljs-keyword,.hljs-name,.hljs-selector-tag{color:#f92672}.hljs-attribute,.hljs-symbol{color:#66d9ef}.hljs-class .hljs-title,.hljs-params{color:#f8f8f2}.hljs-addition,.hljs-built_in,.hljs-builtin-name,.hljs-selector-attr,.hljs-selector-id,.hljs-selector-pseudo,.hljs-string,.hljs-template-variable,.hljs-type,.hljs-variable{color:#e6db74}.hljs-comment,.hljs-deletion,.hljs-meta{color:#75715e}</style>

<center><font size='4px'>🍭 欢迎你的来访啊</font></center>

<center ><font size='4px'>🍭 这里是SL的speak页面啊</font></center>
<center><span id="busuanzi_container_site_uv">已经有<span id="busuanzi_value_site_pv"></span>位可爱的用户访问这个页面了呀~</span><br>
<span id="busuanzi_container_site_pv">这个页面的访问量达到<span id="busuanzi_value_site_pv"></span>了欸!</span>
<div class="is-container"></div>
<div class="btn-group"><input class="button more" type="button" value="加载更多" disabled="disabled"></div>

<div class="inline-tag grey page"></div>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/sviptzk/xiaokang.me@v2.1.1/www/css/speaker.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/sviptzk/xiaokang.me@v2.1.1/www/css/style.css">
<script src="https://cdn.jsdelivr.net/npm/marked/marked.min.js"></script><script src="https://cdn.jsdelivr.net/gh/sviptzk/xiaokang.me@v2.1.1/www/js/Speak.js"></script><script>new Speak({
	per_page: 5,
	owner: 'slqwq',
	repo: 'speak',
	defaultLabelName: 'Deafult',
	defaultLabelColor: '#ffc107',
});</script>

