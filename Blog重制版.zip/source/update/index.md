---
title: update
sticky: 1
date: 2020-05-15 10:02:18
---
更新:

2020/8/18

- 更换cdn.slblog.ga的节点提供商

2020/8/16

+ 更换友链申请方式为添加Issues(只需博主审核，其他不用操作)

2020/8/8

- 关闭Pjax(与页脚养鱼不兼容)
- 移除Aplayer播放器

+ 添加页脚养鱼

+ 公告栏更变🤭

2020/8/1

+ 更改Valine评论字体颜色
+ 更改一些小细节

2020/7/18

+ 升级主题为Pjax分支

+ 添加Aplayer播放器

2020/6/29

- 删除音乐播放器

+ 更新全局字体

+ 使用Hexo-Neat压缩

- 关闭侧边栏的Discord功能

+ 提高加载速度

- 即将废弃 cdn.slblog.ga

2020/6/8

+ 新增文件CDN(每月15GB流量)
+ 侧边栏新增访客信息

- 移除阿里云(大陆)CDN

2020/6/2

- 即将停止 www.slblog.ga 的访问	

+ 实验室新增音乐播放器功能

+ 替换新的播放器

2020/6/1

+ 更换新的域名(blog.slqwq.cn)

2020/5/23

+ 新增阿里云CDN(大陆节点)(不带HTTPS)

2020/5/16

+ 新增cdn.slblog.ga(带HTTPS)cdn

2020/5/15

- CloudFlare出现回源故障，删除CloudFlare。