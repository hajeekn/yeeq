---
title: 网站鸣谢
sticky: 1
date: 2020-05-06 12:46:35
---


博客鸣谢
1.Bmyjacks(B站:bmyjacks)
2.xiobb(B站:xiobb)
3.MBRjun(B站:MBRjun)
4.amemz(B站1:amemz_minecraft,B站2:amemz)
5.Cnoim(B站:Cnoim)
6.萌城酱(B站:1萌城酱,B站2:我是萌城酱)
7.請吃宵夜(B站:請吃宵夜)
8.GitHub Pages(https://pages.github.com/)
9.Coding Pages(https://pages.coding.net.com/)
10.Zeit.co(https://vercel.com/)
11.Fast.io(https://Fast.io/)
12.Jsdelivr(https://jsdelivr.com/)
13.badgen(https://badgen.net/)
14.Hexo(https://hexo.io/)
15.Hexo-theme-Butterfly(1:https://github.com/jerryc127/hexo-theme-butterfly/,2:https://jerryc.me/）
16.夕晴酱(QQ:3314307538)
17.xiaoxu(QQ:2243016926)

在这里附上最真诚的感谢！