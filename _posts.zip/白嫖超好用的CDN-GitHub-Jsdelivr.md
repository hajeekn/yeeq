---
title: 白嫖超好用的CDN(GitHub+Jsdelivr)
sticky: 1
abbrlink: d6df3a18
date: 2020-05-28 11:03:12
tags:
description:
 - 白嫖
cover: https://cdn.jsdelivr.net/gh/slblog-github/BlogFlies/Blog/Pic/2528Cover.png
---
hi，各位好。
今天我来教大家白嫖CDN

# 创建仓库
登陆GitHub
新建一个仓库，名字随意
{% note info %}
一定要是公开!
{% endnote %}

# 生成Tokens
打开
https://github.com/settings/tokens
在页面内选择Generate new token
输入密码后进行下一步
<img src="https://cdn.jsdelivr.net/gh/Open-super/ImgHosting//SuperImg/XbPost2.png"/>
Note为你的名字
{% note warning %}
权限请选择repo
{% endnote %}
选择好后点击Generate token
在跳转的页面里面会有一串代码
比如7513764b740b88c40afc9aa6980989e42axxxxx
这串代码保存下来
接下来会用
# 下载
进入
https://github.com/Molunerfinn/PicGo/releases
选择一个版本(这里以2.2.2演示)
下载完成后双击打开进行安装
# PicGo主页面
安装好后进去PicGo
会出现这个界面
<img src="https://cdn.jsdelivr.net/gh/Open-super/ImgHosting//SuperImg/XbPosts3.png"/>
# 设置图床
选择图床设置
找到GitHub图床
<img src="https://cdn.jsdelivr.net/gh/Open-super/ImgHosting//SuperImg/XbPosts4.png"/>
这些都设置完后进入上传区
将最上面的
<img src="https://cdn.jsdelivr.net/gh/Open-super/ImgHosting//SuperImg/XbPosts5.png"/>
改为GitHub图床
接下来就可以上传一个文件测试了
我来放一个测试图
<img src="https://cdn.jsdelivr.net/gh/Open-super/ImgHosting//SuperImg/Test/界面图.png"/>
可以看到加载的速度非常快
如果有问题请在下方留言!







